from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

class Donor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    blood_type = db.Column(db.String(10), nullable=False)
    contact = db.Column(db.String(150), nullable=False)

class BloodRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    requester_name = db.Column(db.String(150), nullable=False)
    blood_type = db.Column(db.String(10), nullable=False)
    contact = db.Column(db.String(150), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
@login_required
def index():
    blood_requests = BloodRequest.query.all()
    donors = Donor.query.all()
    return render_template('index.html', blood_requests=blood_requests, donors=donors, user=current_user)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password').strip()

        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('register'))

        new_user = User(username=username, password=generate_password_hash(password, method='pbkdf2:sha256'))
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful, please login')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password').strip()

        user = User.query.filter_by(username=username).first()
        if not user or not check_password_hash(user.password, password):
            flash('Invalid username or password')
            return redirect(url_for('login'))

        login_user(user)
        return redirect(url_for('index'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/register_donor', methods=['GET', 'POST'])
@login_required
def register_donor():
    if request.method == 'POST':
        name = request.form.get('name').strip()
        blood_type = request.form.get('blood_type')
        contact = request.form.get('contact').strip()

        if not name or not blood_type or not contact:
            flash('Please fill all fields')
            return redirect(url_for('register_donor'))

        new_donor = Donor(name=name, blood_type=blood_type, contact=contact)
        db.session.add(new_donor)
        db.session.commit()
        flash('Donor registered successfully')
        return redirect(url_for('index'))

    return render_template('register_donor.html')

@app.route('/request_blood', methods=['GET', 'POST'])
@login_required
def request_blood():
    if request.method == 'POST':
        requester_name = request.form.get('requester_name').strip()
        blood_type = request.form.get('blood_type')
        contact = request.form.get('contact').strip()

        if not requester_name or not blood_type or not contact:
            flash('Please fill all fields')
            return redirect(url_for('request_blood'))

        new_request = BloodRequest(requester_name=requester_name, blood_type=blood_type, contact=contact)
        db.session.add(new_request)
        db.session.commit()
        flash('Blood request submitted successfully')
        return redirect(url_for('index'))

    return render_template('request_blood.html')

if __name__ == '__main__':
    # Create tables before running the server (Flask 3.0+ compatible)
    with app.app_context():
        db.create_all()

    app.run(debug=True)
